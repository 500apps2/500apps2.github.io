function setScreenshotUrl(url) {
  console.log(url);
  document.getElementById('target').src = url;
}
